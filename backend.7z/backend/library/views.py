from termios import B75
from django.shortcuts import render
from .models import Book

books = Book.objects.filter()
