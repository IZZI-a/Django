from django.db import models


class Book(models.Model):
    title = models.CharField(max_length= 100, blank = False)
    author = models.CharField(max_length= 50, blank = False)
    genre = models.CharField(max_length= 30, blank = False)
    publication_year = models.IntegerField(blank = False)
    is_read = models.BooleanField()

    def __str__(self):
        return self.title